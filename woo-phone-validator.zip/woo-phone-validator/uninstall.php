<?php
/**
 *  Uninstall
 *
 * @author  Precious Omonzejele <me@codeexplorer.ninja>
 * @since 1.0.0
 */
if (!defined('WP_UNINSTALL_PLUGIN'))
    exit;
